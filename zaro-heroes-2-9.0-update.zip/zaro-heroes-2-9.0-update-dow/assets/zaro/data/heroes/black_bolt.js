function init(hero) {
    hero.setName("Black Bolt Blackagar Boltagon");
    hero.setTier(6);

    
   hero.setHelmet("item.superhero_armor.piece.head");
    hero.setChestplate("item.superhero_armor.piece.torso");
    hero.setLeggings("item.superhero_armor.piece.legs");
    hero.setBoots("item.superhero_armor.piece.boots");

    
    hero.addPowers("zaro:black_bolt");
    hero.addAttribute("PUNCH_DAMAGE", 120.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 2.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 6.0, 0);
    hero.addAttribute("SPRINT_SPEED", 1.2, 1);
    hero.addAttribute("IMPACT_DAMAGE", 0.5, 1);

    hero.addKeyBind("CHARGED_BEAM", "bolt beam", 1);
    hero.addKeyBind("SONIC_WAVES", "wawes", 2);
    
}
