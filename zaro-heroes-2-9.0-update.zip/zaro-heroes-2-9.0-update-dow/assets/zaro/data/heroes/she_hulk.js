   function init(hero) {
    hero.setName("She Hulk");
    hero.setTier(4);

    
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
   
    hero.addPowers("zaro:she");
    hero.addAttribute("PUNCH_DAMAGE", 100.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 6.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 10.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);
    hero.addAttribute("SPRINT_SPEED", 6.2, 1);
    hero.addAttribute("IMPACT_DAMAGE", 100000.5, 1);

 hero.setDefaultScale(2.2);

    hero.addKeyBind("EARTHQUAKE", "key.earthquake", 1);
    hero.addKeyBind("GROUND_SMASH", "key.groundSmash", 2);
}
