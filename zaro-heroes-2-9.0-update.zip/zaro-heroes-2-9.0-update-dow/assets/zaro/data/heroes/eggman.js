function init(hero) {
    hero.setName("Dr Robotnik Eggman");
    hero.setAliases("Sonic");
    hero.setTier(2);

    hero.setHelmet("helmet");
    hero.setChestplate("chesplate");
    hero.setLeggings("leggings");
    hero.setBoots("boots");
    
    hero.addPowers("zaro:tials_levitation");
    hero.addAttribute("PUNCH_DAMAGE", 1.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 2.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 3.5, 0);

    


    hero.setTickHandler((entity, manager) => {
        if (!entity.isSneaking() && !entity.isOnGround() && entity.motionY() < -0.8) {
            manager.setData(entity, "fiskheroes:flying", true);
        }
    });
}

