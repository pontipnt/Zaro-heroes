function init(hero) {
    hero.setName("Green Lantern"); 
    hero.setTier(8);
    
    
  hero.setChestplate("Ring"); 
   
 hero.addPowers("zaro:lantern_ring"); 
    hero.addAttribute("PUNCH_DAMAGE", 7.5, 0); 
    hero.addAttribute("WEAPON_DAMAGE", 4.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
  hero.addAttribute("FALL_RESISTANCE", 4, 0);
   hero.addAttribute("SPRINT_SPEED", 0.2, 1);

     
  hero.addKeyBind("CHARGED_BEAM", "Energy Blast", 1);
   hero.addKeyBind("SHIELD", "key.shield", 3);
    hero.addKeyBind("SPELL_MENU", "key.spellMenu", 4);
    hero.addKeyBind("TELEKINESIS", "Telekinesis", 2);
    
    
hero.setHasProperty(hasProperty);

}
    function hasProperty(entity, property) {
    return property == "BREATHE_SPACE";
}
