var speedster_base = implement("fiskheroes:external/speedster_base");
var utils = implement("fiskheroes:external/utils");

function init(hero) {
    hero.setName("The Flash/Barry allen");
    hero.setTier(5);

    hero.setHelmet("item.superhero_armor.piece.cowl");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addEquipment("fiskheroes:flash_ring");
    hero.addPrimaryEquipment("fiskheroes:flash_ring",true);
    hero.addPowers("zaro:speed_force2");
    hero.addAttribute("PUNCH_DAMAGE", 5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 1.0, 1);
    hero.addAttribute("BASE_SPEED_LEVELS", 7.0, 0);

    hero.addKeyBind("SUPER_SPEED", "key.superSpeed", 1);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotion", 2);

    hero.addKeyBind("MINIATURIZE_SUIT", "Miniaturize Suit", 3);
    
    
    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");

    
    

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.addSoundEvent("MASK_OPEN", "fiskheroes:cowl_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:cowl_mask_close");
    hero.addSoundOverrides("BARRY", speedster_base.mergeSounds("fiskheroes:speed_force", speedster_base.SOUNDS_BARRY));
    hero.addSoundOverrides("TEST", speedster_base.mergeSounds("fiskheroes:speed_force", speedster_base.SOUNDS_TEST));

    hero.setTickHandler((entity, manager) => {
        utils.flightOnIntangibility(entity, manager);
        speedster_base.tick(entity, manager);
        manager.incrementData(entity, "fiskheroes:dyn/speed_sprint_timer", 4, entity.isSprinting() && entity.getData("fiskheroes:speed_sprinting") && entity.getData("fiskheroes:speed") > 0.5);
        if (entity.getData("fiskheroes:speed_sprinting") != entity.getData("fiskheroes:energy_charging")) {
            manager.setData(entity, "fiskheroes:energy_charging", entity.getData("fiskheroes:speed_sprinting"));
        }
    });
}
function isKeyBindEnabled(entity, keyBind) {
    if (keyBind == "INTANGIBILITY") {
        return entity.getData("fiskheroes:speed") > 1 && entity.getData("fiskheroes:dyn/intangibility_cooldown") == 0 && entity.getData("fiskheroes:speeding") && entity.isSprinting() && !(entity.isOnGround());
    }
    return true;
}

function isModifierEnabled(entity, modifier) {
    if (modifier.name() == "fiskheroes:lightning_cast") {
        return entity.getData("fiskheroes:speed") > 1 && entity.getData("fiskheroes:speeding") && entity.isSprinting();
    }
    else if (modifier.name() == "fiskheroes:speed_disintegration") {
        return false;
    }
    return true;
}
