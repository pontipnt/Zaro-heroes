function init(hero) {
    hero.setName("Chaos Emrald/sonic");
    hero.setTier(10);

    
    hero.setChestplate("emrald");

    
    hero.addPowers("zaro:chaos");
    hero.addAttribute("PUNCH_DAMAGE", 12000.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 15.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 6.0, 0);
    hero.addAttribute("SPRINT_SPEED", 6.2, 1);
    hero.addAttribute("IMPACT_DAMAGE", 0.5, 1);

hero.addKeyBind("SPELL_MENU", "key.spellMenu", 4);
    hero.addKeyBind("ENERGY_PROJECTION", "Beam", 1);
    hero.addKeyBind("TELEPORT", "key.teleport", 2);
    hero.addKeyBind("TELEKINESIS", "Telekinesis", 3);
     hero.addKeyBind("SHADOWDOME", "key.shadowDome", 5);
     
     
     hero.setHasProperty(hasProperty);
}

function hasProperty(entity, property) {
    return property == "BREATHE_SPACE";
}
