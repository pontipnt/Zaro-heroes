function init(hero) {
    hero.setName("Nova");
    hero.setTier(8);

   hero.setHelmet("item.superhero_armor.piece.helmet");

    hero.addPowers("zaro:nova_physiology");
    hero.addAttribute("PUNCH_DAMAGE", 8.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);

    hero.addKeyBind("CHARGED_BEAM", "Energy Beam", 1);
    hero.addKeyBind("SHIELD", "Forcefield", 2);
   	hero.addKeyBind("TELEPORT", "Teleport", 4);
    hero.addKeyBind("TELEKINESIS", "Telekinesis", 3);
   hero.addKeyBind("NANITE_TRANSFORM", "Transform", 5);


   hero.setHasProperty(hasProperty);
  hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.addAttributeProfile("INACTIVE", inactiveProfile);
    hero.setAttributeProfile(getProfile);
    hero.setDamageProfile(getProfile);

}
function getTierOverride(entity) {
    return entity.getData("fiskheroes:dyn/nanites") ? 12 : 4;
}

function inactiveProfile(profile) {
    profile.revokeAugments();
}

function getProfile(entity) {
        if (!entity.getData("fiskheroes:dyn/nanites")) {
            return "INACTIVE";
   }
}
 function hasProperty(entity, property) {
  return property == "BREATHE_SPACE";
}

function isModifierEnabled(entity, modifier) {
        if (modifier.name() != "fiskheroes:transformation" && modifier.name() != "fiskheroes:cooldown" && (!entity.getData("fiskheroes:dyn/nanites") || modifier.name() == "fiskheroes:controlled_flight" && entity.getData("fiskheroes:dyn/nanite_timer") < 1)) {

            return false;
        }
        switch (modifier.name()) {
       case "fiskheroes:shield":
            return entity.getData("fiskheroes:dyn/nanites");
       case "fiskheroes:blade":
            return entity.getData("fiskheroes:dyn/nanites");
            default:
                return true;
        }
    }
    function isKeyBindEnabled(entity, keyBind) {
        switch (keyBind) {           
     case "CHARGED_BEAM":
         return entity.getData("fiskheroes:dyn/nanites");
    case "TELEPORT":
         return entity.getData("fiskheroes:dyn/nanites");
    case "TELEKINESIS":
         return entity.getData("fiskheroes:dyn/nanites");
    case "SHIELD":
         return entity.getData("fiskheroes:dyn/nanites");
            default:
                return true;
        }
    }
    function hasProperty(entity, property) {
        switch (property) {
            case "BREATHE_SPACE":
                return !entity.getData("fiskheroes:mask_open") && entity.getData("fiskheroes:dyn/nanites");
            default:
                return false;
        }
    }