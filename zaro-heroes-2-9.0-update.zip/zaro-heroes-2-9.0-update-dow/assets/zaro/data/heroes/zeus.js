var utils = implement("fiskheroes:external/utils");

function init(hero) {
    hero.setName("Zeus Olympus King");
    hero.setTier(8);
    

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
	

hero.addPowers("zaro:charge_energy", "zaro:olympus_king");
hero.addAttribute("BASE_SPEED_LEVELS", 2.0, 0.0);
hero.addAttribute("PUNCH_DAMAGE", 10000.0, 0.0);
hero.addAttribute("FALL_RESISTANCE", 10.0, 0.0);
hero.addAttribute("SPRINT_SPEED", 0.1, 0.0);
hero.addAttribute("JUMP_HEIGHT", 3.0, 0.0);
hero.addAttribute("KNOCKBACK", 2.0, 0.0);
hero.addAttribute("MAX_HEALTH", 14.0, 0.0);

	

hero.addKeyBind("CHARGE_ENERGY", "Charge Energy", 3);
    hero.addKeyBind("CHARGED_BEAM", "Energy Beam", 1);
    hero.addKeyBind("SHIELD", "Forcefield", 2);
   	hero.addKeyBind("TELEPORT", "Teleport", 5);
    hero.addKeyBind("TELEKINESIS", "Telekinesis", 4);


    
   hero.setHasProperty(hasProperty);
   hero.setModifierEnabled(isModifierEnabled);
    

	hero.setDamageProfile(entity => entity.getHeldItem().isEmpty() ? "PUNCH" : null);
	hero.addDamageProfile("PUNCH", {
	"types": {
	"BLUNT": 3.0
        },
	});
	
}

	function hasProperty(entity, property) {
    return property == "BREATHE_SPACE";
}

function isModifierEnabled(entity, modifier) {
    return modifier.name() != "fiskheroes:size_manipulation" || (modifier.id() == "giant") == (entity.getData("fiskheroes:dyn/giant_mode_timer") > 0 || entity.getData("fiskheroes:dyn/giant_mode"));
}