function init(hero) {
    hero.setName("Arishem");
    hero.setTier(10);

    hero.setHelmet("head");
    hero.setChestplate("chestplate");
    hero.setLeggings("pants");
    hero.setBoots("boots");

    hero.addPowers("zaro:arishem_physiology", "zaro:judge", "fiskheroes:vibranium_physiology");
    hero.addAttribute("PUNCH_DAMAGE", 130.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 6.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 8.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 1000000.0, 1);

    hero.addKeyBind("ENERGY_PROJECTION", "key.cosmicBeam", 1);
    hero.addKeyBind("TELEKINESIS", "key.telekinesis", 2);
    hero.addKeyBind("TELEPORT", "key.teleport", 3);
    hero.addKeyBind("SHIELD", "key.forcefield", 4);
    hero.addKeyBind("GROUND_SMASH", "key.groundSmash", 5);

    hero.setDefaultScale(19.0);
    hero.addAttributeProfile("SHIELD", shieldProfile);
    hero.setHasProperty(hasProperty);
}

function shieldProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -0.75, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}

function getAttributeProfile(entity) {
    return entity.getData("fiskheroes:shield_blocking") ? "SHIELD" : null;
}

function hasProperty(entity, property) {
    return property == "BREATHE_SPACE";
}
