function init(hero) {
    hero.setName("Quantum Realm Suit");
    hero.setTier(1);

    
    hero.setChestplate("Suit");
    

    hero.addPowers("zaro:pym_particles");
    hero.addAttribute("PUNCH_DAMAGE", 10.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 6.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 7.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 6.5, 0);

    hero.addKeyBind("SIZE_MANIPULATION", "key.sizeManipulation", 1);
     hero.addKeyBind("MINIATURIZE_SUIT", "key.miniaturizeSuit", 3);
    hero.addKeyBind("AIM", "Energy Blast", 4);

    
    hero.setHasProperty(hasProperty);
	  hero.supplyFunction("canAim", canAim);
  
}

function hasProperty(entity, property) {
    return property == "BREATHE_SPACE";
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty();
}
