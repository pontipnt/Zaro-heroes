function init(hero) {
    hero.setName("Homelander");
    hero.setTier(7);
    
     hero.setHelmet("head");
    hero.setChestplate("chestplate");
    hero.setLeggings("pants");
    hero.setBoots("boots");
    
    hero.addPowers("zaro:homelander");
    hero.addAttribute("PUNCH_DAMAGE", 5.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 2.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.9, 0);
    hero.addAttribute("BASE_SPEED_LEVELS", 3.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 3.5, 0);

    hero.addKeyBind("SUPER_SPEED", "SuperSpeed", 1);
    hero.addKeyBind("HEAT_VISION", "Heat Vision", 2);

    hero.setTickHandler((entity, manager) => {
        manager.incrementData(entity, "fiskheroes:dyn/speed_sprint_timer", 4, entity.isSprinting() && entity.getData("fiskheroes:speed_sprinting") && entity.getData("fiskheroes:speed") > 0.5);
        if (!entity.getData("fiskheroes:speeding")) {
            manager.setData(entity, "fiskheroes:speeding", false);
        }
    });
}