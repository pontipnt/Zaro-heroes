function init(hero) {
    hero.setName("Darkhold Book");
    hero.setTier(8);
    
    hero.setChestplate("Darkhold Book");
    
    hero.addPowers("zaro:darkhold_chton");
    hero.addAttribute("PUNCH_DAMAGE", 4.0, 0);

    hero.addKeyBind("Darkhold_BOOK", "Darkhold Book", 1);
    hero.addKeyBind("HEAT_VISION", "Write name on note (look at player)", 2);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
}

function isModifierEnabled(entity, modifier) {  
    switch (modifier.name()) {
        case "fiskheroes:heat_vision":
            return entity.getData("fiskheroes:dyn/nanites");
        default:
            return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
        case "HEAT_VISION":
            return entity.getData("fiskheroes:dyn/nanites");
        default:
            return true;
    }
}
