function init(hero) {
    hero.setName("Bugraak/YouTuber");
    hero.setTier(8);

    hero.setChestplate("item.superhero_armor.piece.chestpiece");

    hero.addPowers("zaro:mcevi");
    hero.addAttribute("FALL_RESISTANCE", 1, 1);
    hero.addAttribute("PUNCH_DAMAGE", 40.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.4, 1);
    hero.addAttribute("JUMP_HEIGHT", 3.0, 0);

    hero.addKeyBind("ENERGY_PROJECTION", "Beam", 1);
    hero.addKeyBind("TELEPORT", "key.teleport", 2);
    hero.addKeyBind("TELEKINESIS", "Telekinesis", 3);
     hero.addKeyBind("SHADOWDOME", "key.shadowDome", 5);
     
      
     hero.setHasProperty(hasProperty);

}

function hasProperty(entity, property) {
    return property == "BREATHE_SPACE";
}
