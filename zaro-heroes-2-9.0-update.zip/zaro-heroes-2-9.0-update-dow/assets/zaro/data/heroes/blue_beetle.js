var landing = implement("fiskheroes:external/superhero_landing");

function init(hero) {
    hero.setName("Blue Beetle");
    hero.setTier(8);

    hero.setChestplate("Chestpiece");

    hero.addPowers("zaro:beetle");
    hero.addAttribute("PUNCH_DAMAGE", 8.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 1.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);

    hero.addKeyBind("CHARGED_BEAM", "key.repulsorBeams", 1);
    hero.addKeyBind("AIM", "key.aim", 3);
    hero.addKeyBind("BLADE", "key.blade", 2);
    hero.addKeyBind("SHIELD", "key.shield", 2);



    hero.addSoundEvent("AIM_START", "fiskheroes:repulsor_charge");
    hero.addSoundEvent("AIM_STOP", "fiskheroes:repulsor_powerdown");

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.supplyFunction("canAim", canAim);
    hero.addAttributeProfile("SHIELD", shieldProfile);
    hero.setAttributeProfile(getAttributeProfile);
    hero.addAttributeProfile("BLADE", bladeProfile);
    hero.setDamageProfile(getAttributeProfile);
    hero.addDamageProfile("BLADE", {
        "types": {
            "SHARP": 1.0,
            "ENERGY": 0.7
        }
    });
    hero.setTickHandler((entity, manager) => {
        var flying = entity.getData("fiskheroes:flying");
        manager.incrementData(entity, "fiskheroes:dyn/booster_timer", 2, flying);

        var item = entity.getHeldItem();
        flying &= !entity.getData("fiskheroes:beam_charging") && !entity.as("PLAYER").isUsingItem();
        manager.incrementData(entity, "fiskheroes:dyn/booster_r_timer", 2, flying && item.isEmpty() && !entity.isPunching() && entity.getData("fiskheroes:blade_timer") == 0);
        manager.incrementData(entity, "fiskheroes:dyn/booster_l_timer", 2, flying && !item.doesNeedTwoHands());

        landing.tick(entity, manager);
    });
}


function shieldProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", -0.75, 1);
    profile.addAttribute("JUMP_HEIGHT", -2.0, 1);
}


function bladeProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("PUNCH_DAMAGE", 10.5, 0);
    profile.addAttribute("JUMP_HEIGHT", 1.5, 0);
    profile.addAttribute("FALL_RESISTANCE", 9.5, 0);
}

function getAttributeProfile(entity) {
    if (entity.getData("fiskheroes:shield_blocking")) {
        return "SHIELD"
    } if (entity.getData("fiskheroes:blade")) {
       return "BLADE"
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
        case "AIM":
            return !entity.getData("fiskheroes:tentacles");
        case "CHARGED_BEAM":
            return !entity.getData("fiskheroes:tentacles");
        case "SHIELD":
            return (entity.getData("fiskheroes:blade_timer") == 0 || entity.isBookPlayer()) && !entity.getData("fiskheroes:flying") && !entity.getData("fiskheroes:tentacles");
        case "BLADE":
            return !entity.getData("fiskheroes:tentacles") && entity.getData("fiskheroes:shield_timer") > 0 || entity.getData("fiskheroes:blade_timer") > 0 || entity.isBookPlayer() || entity.getData("fiskheroes:flying");
    }
    return true;
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:blade":
            return entity.getData("fiskheroes:beam_charge") == 0 && !entity.getData("fiskheroes:aiming") && !(entity.getData("fiskheroes:shield") && entity.getData("fiskheroes:blade")) && !(entity.isSprinting() && entity.getData("fiskheroes:flying"));
        case "fiskheroes:shield":
            return entity.getData("fiskheroes:beam_charge") == 0 && !entity.getData("fiskheroes:aiming") && !(entity.getData("fiskheroes:shield") && entity.getData("fiskheroes:blade")) && !entity.getData("fiskheroes:flying");
        case "fiskheroes:controlled_flight":
            return !entity.getData("fiskheroes:tentacles")
            default:
            return true;
    }
}

function canAim(entity) {
    return entity.getHeldItem().isEmpty() && !entity.getData("fiskheroes:shield");
}