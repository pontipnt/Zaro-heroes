extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:the_flash",
    "layer2": "zaro:the_flash"
});

var speedster = implement("fiskheroes:external/speedster_utils");
var flames = implement("fiskheroes:external/flames");
var hand_flames;

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "HELMET" && (entity.is("DISPLAY") && entity.as("DISPLAY").isStatic() ? entity.getData("fiskheroes:mask_open") : entity.getData("fiskheroes:mask_open_timer2") > 0.35)) {
            return "layer2";
        }
        return renderLayer == "LEGGINGS" ? "layer2" : "layer1";
    });
}

function initEffects(renderer) {
    speedster.init(renderer, "fiskheroes:lightning_red");
    var fire = renderer.createResource("ICON", "fiskheroes:blue_fire_layer_%s");
    hand_flames = flames.createHands(renderer, fire, false);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "flash.MASK", "fiskheroes:remove_cowl")
        .setData((entity, data) => {
            var f = entity.getInterpolatedData("fiskheroes:mask_open_timer2");
            data.load(f < 1 ? f : 0);
        });
}