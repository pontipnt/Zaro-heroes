extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:electro",
    "layer2": "zaro:electro"
});

var utils = implement("fiskheroes:external/utils");
var lightning1;

function initEffects(renderer) {
    utils.bindBeam(renderer, "fiskheroes:energy_projection", "zaro:zeus", "body", 0xFFDF00, [
        { "firstPerson": [0.0, 6.0, 0.0], "offset": [0.0, 5.0, -4.0], "size": [4.0, 4.0] }
    ]);

utils.bindCloud(renderer, "fiskheroes:teleportation", "zaro:zeus");

var magic = renderer.bindProperty("fiskheroes:spellcasting");
    magic.colorEarthCrack.set(0xFFDF00);
    magic.colorAtmosphere.set(0xFFDF00);
    magic.colorGeneric.set(0xFFDF00);
    magic.colorWhip.set(0xFFDF00);

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "zaro:zeus","body", 0xFFDF00, [
        { "firstPerson": [-4.5, 3.75, -8.0], "offset": [-0.5, 9.0, 0.0], "size": [3.0, 3.0],"anchor": "rightArm" },
        { "firstPerson": [4.5, 3.75, -8.0], "offset": [0.5, 9.0, 0.0], "size": [3.0, 3.0], "anchor": "leftArm" }

    ]);
	var trail = renderer.bindProperty("fiskheroes:trail");
    trail.setTrail(renderer.createResource("TRAIL", "fiskheroes:lightning_comics_yellow"));
    trail.setCondition(entity => entity.getData("fiskheroes:flying"));    
	
	utils.bindBeam(renderer, "fiskheroes:lightning_cast", "fiskheroes:lightning_cast", "rightArm", 0xe7dc12, [
        { "firstPerson": [-8.0, 4.5, -10.0], "offset": [-0.5, 9.0, 0.0], "size": [0.75, 0.75] }
    ]);
	
	var beam = renderer.createResource("BEAM_RENDERER", "zaro:zeus");
    lightning1 = utils.createLines(renderer, beam, 0xFFDF00, [
        {"start": [0, 0.7, 0], "end": [0.0, -1.0, 0.0], "size": [5.0, 4.0, 5.0]},
    ]);
    lightning1.setOffset(1.0, 8.0, 0.0).setScale(5.0);
    lightning1.anchor.set("rightArm");
    lightning1.mirror = true;
}
function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("basic.CHARGED_BEAM");
    
	addAnimationWithData(renderer, "basic.AIMING", "fiskheroes:dual_aiming", "fiskheroes:beam_charge");
    utils.addFlightAnimation(renderer, "lightning1.FLIGHT", "fiskheroes:flight/propelled_hands.anim.json");
    utils.addHoverAnimation(renderer, "lightning1.HOVER", "fiskheroes:flight/idle/propelled_hands");

}

function render(entity, renderLayer, isFirstPersonArm) {
    if (renderLayer == "CHESTPLATE") {
        lightning1.progress = entity.getInterpolatedData("fiskheroes:beam_charge") || entity.getInterpolatedData("fiskheroes:energy_projection");
        lightning1.render();
    }
}