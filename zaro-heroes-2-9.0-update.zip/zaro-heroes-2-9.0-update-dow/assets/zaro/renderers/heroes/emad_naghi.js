extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:emad_naghi",
    "layer2": "zaro:emad_naghi"
});

var utils = implement("fiskheroes:external/utils");
var speedster = implement("fiskheroes:external/speedster_utils");

function init(renderer) {
    parent.init(renderer);
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");
}

function initEffects(renderer) {
    speedster.init(renderer, "fiskheroes:lightning_zoom");
}