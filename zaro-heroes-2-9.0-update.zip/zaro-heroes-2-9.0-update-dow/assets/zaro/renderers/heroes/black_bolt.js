extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:marvel/black_bolt/black_bolt",
    "layer2": "zaro:marvel/black_bolt/black_bolt",
    "web_wings": "zaro:marvel/black_bolt/black_bolt_wings"
});

var web_wings;

var utils = implement("fiskheroes:external/utils");

function initEffects(renderer) {
    web_wings = renderer.createEffect("fiskheroes:wingsuit");
    web_wings.texture.set("web_wings");
    web_wings.opacity = 1.0;
    
	utils.bindBeam(renderer, "fiskheroes:charged_beam", "zaro:bolt_beam", "head", 0xe6e6e6, [
        { "firstPerson": [0.0, 0.0, 0.0], "offset": [0.0, 0.0, 0.0], "size": [4.0, 4.0] }
    ])
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm && renderLayer == "CHESTPLATE") {
        web_wings.unfold = entity.getInterpolatedData("fiskheroes:wing_animation_timer");
        web_wings.render();
    }
}