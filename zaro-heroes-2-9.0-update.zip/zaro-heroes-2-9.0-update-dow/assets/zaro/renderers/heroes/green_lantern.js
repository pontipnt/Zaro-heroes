extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:green_lantern",
    "layer2": "zaro:green_lantern"
});

var utils = implement("fiskheroes:external/utils");


function init(renderer) {
    parent.init(renderer);
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");
}

function initEffects(renderer) {

    utils.bindTrail(renderer, "fiskheroes:shazam");
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskheroes:cold_beam", "rightArm", 0x27FA4A, [
        { "firstPerson": [-4.5, 3.75, -8.0], "offset": [-0.5, 9.0, 0.0], "size": [3.0, 3.0] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_antimatter"));



    var magic = renderer.bindProperty("fiskheroes:spellcasting");
    magic.colorEarthCrack.set(0x27FA4A);
    magic.colorAtmosphere.set(0x27FA4A);
    magic.colorGeneric.set(0x27FA4A);
    magic.colorWhip.set(0x27FA4A);
   
    var forcefield = renderer.bindProperty("fiskheroes:forcefield");
    forcefield.color.set(0x42ff03);
    forcefield.setShape(36, 18).setOffset(0.0, 6.0, 0.0).setScale(1.25);
    forcefield.setCondition(entity => {
        forcefield.opacity = entity.getInterpolatedData("fiskheroes:shield_blocking_timer") * 0.15;
        return true;
    });

    utils.bindCloud(renderer, "fiskheroes:telekinesis", "zaro:doctor_doom_telekenesis");
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("basic.CHARGED_BEAM");

    addAnimationWithData(renderer, "antimonitor.ANTIBLAST", "fiskheroes:aiming", "fiskheroes:beam_charge");
    
    utils.addFlightAnimation(renderer, "shazam.FLIGHT", "fiskheroes:flight/default.anim.json");
    utils.addHoverAnimation(renderer, "shazam.HOVER", "fiskheroes:flight/idle/default");
}
