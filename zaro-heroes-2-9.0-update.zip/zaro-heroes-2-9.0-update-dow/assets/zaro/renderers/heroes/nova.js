extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:nova",
    "layer2": "zaro:nova"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");
}

function initEffects(renderer) {

    var forcefield = renderer.bindProperty("fiskheroes:forcefield");
    forcefield.color.set(0x00bfff);
    forcefield.setShape(36, 18).setOffset(0.0, 6.0, 0.0).setScale(2.5);
    forcefield.setCondition(entity => {
        forcefield.opacity = entity.getInterpolatedData("fiskheroes:shield_blocking_timer") * 0.2;
        return true;
    });
	
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskheroes:cold_beam", "body", 0x87cefa, [
        { "firstPerson": [-3.75, 3.0, -8.0], "offset": [0.5, 12.0, 0.0], "size": [3.0, 3.0], "anchor": "leftArm" },
        { "firstPerson": [3.75, 3.0, -8.0], "offset": [-0.5, 12.0, 0.0], "size": [3.0, 3.0], "anchor": "rightArm" }
    ]);
	
    glow = renderer.createEffect("fiskheroes:glowerlay");
    glow.color.set(0x7fc7ff);
	utils.bindParticles(renderer, "fiskheroes:harbinger_glow");

	utils.bindCloud(renderer, "fiskheroes:telekinesis", "zaro:telekinesis_arishem");
}


function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("basic.AIM");
    renderer.removeCustomAnimation("basic.ENERGY_PROJ");
    renderer.removeCustomAnimation("basic.BLOCKING");
   addAnimation(renderer, "basic.AIMING", "fiskheroes:dual_aiming").setData((entity, data) => {
        var charge = entity.getInterpolatedData("fiskheroes:beam_charge");
        data.load(Math.max(entity.getInterpolatedData("fiskheroes:aiming_timer"), entity.getData("fiskheroes:beam_charging") ? Math.min(charge * 3, 1) : Math.max(charge * 5 - 4, 0)));
    });

    
    utils.addFlightAnimation(renderer, "mmcw.FLIGHT", "fiskheroes:flight/default_arms_forward.anim.json");

    utils.addHoverAnimation(renderer, "mmcw.HOVER", "fiskheroes:flight/idle/neutral");
}
function render(entity, renderLayer, isFirstPersonArm) {
    glow.opacity = entity.getInterpolatedData("fiskheroes:teleport_timer");
    glow.render();
}