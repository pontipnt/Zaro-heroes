extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:yok",
    "layer2": "zaro:yok",
    "sword": "zaro:darkhold",
});

var utils = implement("fiskheroes:external/utils");

var darkhold;

function init(renderer) {
    parent.init(renderer);
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");;
}

function initEffects(renderer) {
    darkhold = renderer.createEffect("fiskheroes:model");
    darkhold.setModel(utils.createModel(renderer, "zaro:darkhold", "sword"));
    darkhold.anchor.set("rightArm");
    darkhold.mirror = false;


    utils.bindBeam(renderer, "fiskheroes:heat_vision", "zaro:yok", "rightArm", 0xFF0000, [
        { "firstPerson": [-4.30, 10.20, -0.10], "offset": [-4.30, 10.20, -0.10], "size": [1.0, 0.5] },
    ]);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimationWithData(renderer, "mando.HEAT_VISION", "fiskheroes:aiming", "fiskheroes:heat_vision");
}

function render(entity, renderLayer, isFirstPersonArm) { 
    if (renderLayer == "CHESTPLATE") {
        darkhold.opacity = entity.getInterpolatedData("fiskheroes:dyn/nanite_timer");
        darkhold.render();
    }
}