extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:cyborg/cyborg",
    "layer2": "zaro:cyborg/cyborg",
    "cannon1": "zaro:cyborg/cyborg_cannon1",
    "cannon2": "zaro:cyborg/cyborg_cannon2",
    "cannon1_lights": "zaro:cyborg/cyborg_cannon1_lights",
    "cannon2_lights": "zaro:cyborg/cyborg_cannon2_lights",
    "cannon_inner": "zaro:cyborg/cyborg_cannon_inner",
});

var utils = implement("fiskheroes:external/utils");
var mk50_cannon = implement("fiskheroes:external/mk50_cannon");
var iron_man_boosters = implement("fiskheroes:external/iron_man_boosters");

var cannon;
var boosters;

function init(renderer) {
    parent.init(renderer);
    renderer.setLights((entity, renderLayer) => renderLayer == "LEGGINGS" ?  "lights_layer2" : "lights_layer1");
}

function initEffects(renderer) {

    cannon = mk50_cannon.create(renderer, "rightArm", 0xFF3333);
    boosters = iron_man_boosters.create(renderer, "extraheroes:red_fire_layer_%s", true);
    

    utils.addCameraShake(renderer, 0.015, 1.5, "fiskheroes:flight_boost_timer");
    utils.bindParticles(renderer, "fiskheroes:iron_man").setCondition(entity => entity.getData("fiskheroes:flying"));
    renderer.bindProperty("fiskheroes:energy_blast").color.set(0xFF0000);

    utils.bindBeam(renderer, "fiskheroes:heat_vision", "fiskheroes:heat_vision", "head", 0xFF0000, [
        { "firstPerson": [2.2, 0.0, 2.0], "offset": [2.2, -3.3, -4.0], "size": [1.0, 0.5] },
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_heat_vision"));
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    utils.addFlightAnimationWithLanding(renderer, "iron_man.FLIGHT", "fiskheroes:flight/iron_man.anim.json");
    utils.addHoverAnimation(renderer, "iron_man.HOVER", "fiskheroes:flight/idle/iron_man");
    addAnimationWithData(renderer, "iron_man.LAND", "fiskheroes:superhero_landing", "fiskheroes:dyn/superhero_landing_timer")
        .priority = -8;
    
    addAnimationWithData(renderer, "iron_man.ROLL", "fiskheroes:flight/barrel_roll", "fiskheroes:barrel_roll_timer")
        .priority = 10;
}

function render(entity, renderLayer, isFirstPersonArm) {
    cannon.render(entity.getInterpolatedData("fiskheroes:aimed_timer"));
    boosters.render(entity, renderLayer, isFirstPersonArm, true);
}
