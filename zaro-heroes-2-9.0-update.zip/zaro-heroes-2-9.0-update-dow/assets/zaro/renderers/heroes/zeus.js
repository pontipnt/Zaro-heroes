extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:zeus_layer1",
    "layer2": "zaro:zeus_layer2",
    "zeus_thunder": "zaro:zeus_thunder_eyes",
    "lights": "zaro:zeus_thunder",
    "layer1_lights": "zaro:zeus_thunder",
 });


var utils = implement("fiskheroes:external/utils");


function init(renderer) {
    parent.init(renderer);
 renderer.setLights((entity, renderLayer) => renderLayer == "LEGGINGS" ? "layer1_lights" : "layer1_lights");    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");
}


function initEffects(renderer) {
    utils.bindBeam(renderer, "fiskheroes:energy_manipulation", "fiskheroes:cold_beam", "rightArm",0xFFFF6D, [
        { "firstPerson": [-0.5, 19.0, -12.0], "offset": [-2.5, 0.0, -7.0], "size": [1.0,1.0] }
    ]);

  zeus_thunder = renderer.createEffect("fiskheroes:overlay");
    zeus_thunder.texture.set(null, "zeus_thunder");

var forcefield = renderer.bindProperty("fiskheroes:forcefield");
    forcefield.color.set(0xFFFF6D);
    forcefield.setShape(36, 18).setOffset(0.0, 6.0, 0.0).setScale(2.5);
    forcefield.setCondition(entity => {
        forcefield.opacity = entity.getInterpolatedData("fiskheroes:shield_blocking_timer") * 0.2;
        return true;
    });
	
    utils.bindBeam(renderer, "fiskheroes:charged_beam", "fiskheroes:cold_beam", "body", 0xFFFF6D, [
        { "firstPerson": [-3.75, 3.0, -8.0], "offset": [0.5, 12.0, 0.0], "size": [3.0, 3.0], "anchor": "leftArm" },
        { "firstPerson": [3.75, 3.0, -8.0], "offset": [-0.5, 12.0, 0.0], "size": [3.0, 3.0], "anchor": "rightArm" }
    ]);
	
    glow = renderer.createEffect("fiskheroes:glowerlay");
    glow.color.set(0xFFFF6D);
	utils.bindParticles(renderer, "fiskheroes:harbinger_glow");

	utils.bindCloud(renderer, "fiskheroes:telekinesis", "zaro:telekinesis_zeus");
}


function initAnimations(renderer) {
    parent.initAnimations(renderer);
    renderer.removeCustomAnimation("basic.AIM");
    renderer.removeCustomAnimation("basic.ENERGY_PROJ");
    renderer.removeCustomAnimation("basic.BLOCKING");

   addAnimation(renderer, "basic.AIMING", "fiskheroes:dual_aiming").setData((entity, data) => {
        var charge = entity.getInterpolatedData("fiskheroes:beam_charge");
        data.load(Math.max(entity.getInterpolatedData("fiskheroes:aiming_timer"), entity.getData("fiskheroes:beam_charging") ? Math.min(charge * 3, 1) : Math.max(charge * 5 - 4, 0)));
    });
}

function render(entity, renderLayer, isFirstPersonArm) {
    glow.opacity = entity.getInterpolatedData("fiskheroes:teleport_timer");
    glow.render();
}

