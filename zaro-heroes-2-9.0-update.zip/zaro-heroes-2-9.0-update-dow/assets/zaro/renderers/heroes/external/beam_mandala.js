function create(renderer, color, beam) {
    var shape = renderer.createResource("SHAPE", "zaro:beam_mandala");
    var magic_core = renderer.createEffect("fiskheroes:lines").setShape(shape).setRenderer(beam);
    magic_core.setOffset(1.0, 11.0, 0.0).setRotation(0.0, 0.0, 10.0).setScale(5);
    magic_core.color.set(color);
    magic_core.anchor.set("rightArm");

    var shape = renderer.createResource("SHAPE", "zaro:beam_circle");
    var circle = renderer.createEffect("fiskheroes:lines").setShape(shape).setRenderer(beam);
    circle.color.set(color);
    circle.anchor.set("rightArm");

    return {
        render: (entity, isFirstPersonArm) => {
            var beam_charge = entity.getInterpolatedData("fiskheroes:beam_charge");
            magic_core.progress = beam_charge;

            magic_core.render();

            var shoot_timer = entity.getInterpolatedData("fiskheroes:beam_shooting_timer");

            circle.progress = beam_charge;
            circle.setOffset(1.0, 9.5 + 3.5 * Math.min(Math.max(shoot_timer * 2, 0), 1), 0.0);
            circle.setRotation(0.0, 0.0, 10.0);
            circle.setScale(5 * 0.775);
            circle.render();

            circle.progress = beam_charge;
            circle.setOffset(1.0, 8.0 + 7.0 * Math.min(Math.max(shoot_timer * 2 - 1/3, 0), 1), 0.0);
            circle.setRotation(0.0, 90.0, 10.0);
            circle.setScale(5 * 0.875);
            circle.render();

            circle.progress = beam_charge;
            circle.setOffset(1.0, 6.5 + 10.5 * Math.min(Math.max(shoot_timer * 2 - 2/3, 0), 1), 0.0);
            circle.setRotation(0.0, 180.0, 10.0);
            circle.setScale(5 * 0.95);
            circle.render();

            circle.progress = beam_charge;
            circle.setOffset(1.0, 5.0 + 14 * Math.min(Math.max(shoot_timer * 2 - 1, 0), 1), 0.0);
            circle.setRotation(0.0, 270.0, 10.0);
            circle.setScale(5);
            circle.render();
        }
    };
}
