extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:youtuber/minecraft_evi/minecraft_evi",
    "layer2": "zaro:youtuber/minecraft_evi/minecraft_evi"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");
}

function initEffects(renderer) {
   
    var forcefield = renderer.bindProperty("fiskheroes:forcefield");
    forcefield.color.set(0x42ff03);
    forcefield.setShape(36, 18).setOffset(0.0, 6.0, 0.0).setScale(1.25);
    forcefield.setCondition(entity => {
        forcefield.opacity = entity.getInterpolatedData("fiskheroes:shield_blocking_timer") * 0.15;
        return true;
    });

utils.bindCloud(renderer, "fiskheroes:teleportation", "zaro:doctor_doom_teleport");
    utils.bindCloud(renderer, "fiskheroes:telekinesis", "zaro:doctor_doom_telekenesis");
    utils.bindBeam(renderer, "fiskheroes:energy_projection", "zaro:zeus", "body", 0x27FA4A, [
        { "firstPerson": [0.0, 6.0, 0.0], "offset": [0.0, 5.0, -4.0], "size": [4.0, 4.0] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_energy_projection"));
    
}


function initAnimations(renderer) {
    parent.initAnimations(renderer);
    utils.addFlightAnimation(renderer, "shazam.FLIGHT", "fiskheroes:flight/default.anim.json");
}

