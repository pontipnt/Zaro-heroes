extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:shriek",
    "layer2": "zaro:shriek"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");
}