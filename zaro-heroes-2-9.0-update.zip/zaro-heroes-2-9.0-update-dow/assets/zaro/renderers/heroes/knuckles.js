extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:knuckles",
    "layer2": "zaro:knuckles",
    "eyes": "fiskheroes:reverse_flash_eyes"
});

var speedster = implement("fiskheroes:external/speedster_utils");

var vibration;

function init(renderer) {
    parent.init(renderer);
    renderer.setLights((entity, renderLayer) => renderLayer == "HELMET" && entity.getData("fiskheroes:mask_open") ? "eyes" : null);
}

function initEffects(renderer) {
    vibration = renderer.createEffect("fiskheroes:vibration");

    speedster.init(renderer, "fiskheroes:lightning_red");
}

function render(entity, renderLayer, isFirstPersonArm) {
    if ((!entity.is("DISPLAY") || entity.as("DISPLAY").getDisplayType() === "BOOK_PREVIEW") && entity.getData("fiskheroes:mask_open")) {
        vibration.render();
    }
}
