extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "zaro:spot",
    "layer2": "zaro:spot"
});

var utils = implement("fiskheroes:external/utils");

function init(renderer) {
    parent.init(renderer);
    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");
}

function initEffects(renderer) {
    utils.bindCloud(renderer, "fiskheroes:teleportation", "zaro:spot");
}
